script.on_configuration_changed(function()

    -- First increase maximum allowed stack size
end)