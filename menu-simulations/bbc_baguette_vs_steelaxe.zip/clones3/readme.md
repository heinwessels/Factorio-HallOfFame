http://bbchampions.org

bbc.factorio@gmail.com @BiterBattles (twitter)

MAP :
- Revealing Spawn (127x127) after 10s for reroll purpose
- Resources in spawn are in working progress, expect changes (less resources)
- Walls, turrets, wooden chests are randomly placed, turrets have 2 to 16 magazines.
- Map sides are perfectly symmetrical.
- 3 bonus turrets are placed near the silo with 12 magazines each.
- Worms are closer (dist / 2)
- Wrecks give {5 iron-2 copper-1 steel-5 coal-5 stone-2 gear-2 GC-2 belt-1 inserter}
- Mines, Artillery, Atomic bomb are disabled.
- ######### DONT USE GLITCHS, BUGS etc. kepp the spirit of biter battles.

TEAM MANAGER :
- Team manager : check the "?" button for all infos.
- Players have to be demoted (anti-cheat), 4th team mate (spy|coach|substitute) and spectators also have to be demoted.
- Streamers have to be promoted (access to larger view, to crafting list and to inventory of players)
- Reroll map up to twice (no roll back) decided by team "AtHome"
- 4 Starter packs : Regular, Science, Robot, Combat (see content ingame)
- No inventory, items from starter pack are split into 3 chests

- No need for trusting players, everyone can use deconstruction planner and cut/copy/paste
- Behemoth league (150%) : importing blue prints from personal library is disabled
- Biter League (100%) : importing blue prints from personal library is enabled (automatically)
- Both leagues : you still can create and use BPs during the game

GAME :
- Game starts at dawn.
- Evo starts at 0, Threats starts at 9
- Unless threat<0 : min=2 to max=7 groups every other minute, depending on threats ratio
- First attack targets north or south randomly (no big deal)
- Automatic clear-corpses every 15 min (/clear-corpses 'radius' still active)
- You can damage your silo but you can't destroy it (will stay at 9 health)
- Satellite and Silo researches are granted once you have researched speed-module-3
- Groups of biters come from all side and will use same waypoints to attack other side (slighlty randomized)

PAUSE/SUBSTITUTE :
- Freezing/Pausing also freeze biters, but not turrets, nor factory, nor personal craftings ... no idea to change this unfortunately
- Team can ask for a pause to the referee once per hour
- For any reason (e.g. player disconnects or cant keep up with the game), after moving this player to spectators, referee can switch 4th team mate to the team. When player reconnects, he can go back to the field after 4th was removed.
One rule : never more than 3 players on one side !

ENDGAME :
- Timer measures real game time, deducing freeze/pause time
- After 2 hours of game play, ARMAGEDDON is activated. Meaning that both team will be at least at 90% evolution after 30 minutes,
regardless of natural evo and science sendings. Lower EVO at 2h will grow slower than other, minimum is 1% per min.
(This rule aim to end games before 3h)

- Results and stats are visible at the end of the game, and saved to be imported on the website.

SPECIAL COMMAND
- Command to reset the map at any time : be careful ! 
/force-map-reset 'reason' (useful for training, forbidden in official matches)


PATCH NOTE  :
date :
- Biter League (100%) : importing blue prints from personal library is enabled (automatically)
- Training mode : Armageddon boost depends on own team